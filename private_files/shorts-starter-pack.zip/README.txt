YouTube Shorts Starter Pack — 300 vertical videos.
Sample only.