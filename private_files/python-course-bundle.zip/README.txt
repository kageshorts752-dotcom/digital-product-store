Python for Beginners — 42 video lessons.
Sample only.